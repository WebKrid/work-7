Vue.component('error', {
    template:
        `ошибка соединения с сервером!`
});